# student-result-management-system
A simple and effective way to view exam result for students.
